<br><br>

<?php if(session('success')): ?>
<div class="container">
    <div class="alert alert-success">
    <center>    <?php echo e(session('success')); ?> </center>
    </div>
	</div>
<?php endif; ?>



<?php if(session('danger')): ?>
<div class="container">

    <div class="alert alert-danger">
    <center>    <?php echo e(session('danger')); ?> </center>
    </div>
		</div>

<?php endif; ?>


<?php if(session('info')): ?>
<div class="container">

    <div class="alert alert-info">
    <center>    <?php echo e(session('info')); ?> </center>
    </div>
		</div>

<?php endif; ?>


<?php if(session('warning')): ?>
<div class="container">

    <div class="alert alert-warning">
    <center>    <?php echo e(session('warning')); ?> </center>
    </div>
		</div>

<?php endif; ?><?php /**PATH C:\Users\Ibrahim Elsanhouri\Desktop\komait\resources\views/layouts/alerts.blade.php ENDPATH**/ ?>