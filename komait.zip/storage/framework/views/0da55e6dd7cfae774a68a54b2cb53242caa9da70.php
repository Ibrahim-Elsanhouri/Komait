<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/crudbooster/assets/summernote/summernote.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('bottom'); ?>
    <script type="text/javascript" src="<?php echo e(asset('vendor/crudbooster/assets/summernote/summernote.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Ibrahim Elsanhouri\Desktop\komait\vendor\crocodicstudio\crudbooster\src/views/default/type_components/wysiwyg/asset.blade.php ENDPATH**/ ?>