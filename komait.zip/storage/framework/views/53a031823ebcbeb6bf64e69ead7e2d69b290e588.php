<?php $__env->startSection('content'); ?>





    <!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb_iner text-center">
                        <div class="breadcrumb_iner_item">
                            <h2>استشاراتي</h2>
                            <p>حسابي<span>/<span>استشاراتي</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

  
  <section class="contact-section section_padding">
    <div class="container">
      <div class="d-none d-sm-block mb-5 pb-4">
        
<?php echo $__env->make('layouts.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="row">
        <div class="col-12">
        <div class="text-center">
          <h2 class="contact-title">قائمة الاستشارات</h2>

        </div>
        </div>
        <div class="col-lg-1"></div>
        <div class="col-lg-10">
   
   
<table class="table" style="direction:rtl;">
  <thead>
    <tr>
      <th scope="col">
          <div class="text-center">رقم الاستشارة</div>

      
       </th>
      <th scope="col">          <div class="text-center"> الاستشارة</div>
</th>
    <th scope="col">

    <div class="text-center">الملاحظات</div>
    
    
    </th>
      <th scope="col">
                <div class="text-center">العروض  </div>

      
      </th>
       <th scope="col">
                <div class="text-center">الاتفاقية  </div>

      
      </th>

            <th scope="col"> 
                      <div class="text-center">تاريخ التقديم</div>

            </th>


            <th scope="col"> 
                      <div class="text-center">الحالة</div>

            </th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $myconsultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myconsultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
      <th scope="row">
                <div class="text-center">K2020-<?php echo e($myconsultant->id); ?></div>
      </th>
      <td>                  <div class="text-center"><?php echo e($myconsultant->subject); ?></div>
</td>
    <td>
    <div class="text-center">
    

        <a href="<?php echo e(route('note.consultant_notes' ,   $myconsultant->id    )); ?>"> <i class="fa fa-envelope"></i><span> <?php echo e($myconsultant->notes->count()); ?> </span></a>

    </div>
    
</td>
      <td>
      <div class="text-center">
        <a href="<?php echo e(route('offer.consultant_offers' ,  $myconsultant->id  )); ?>"> <i class="fa fa-money"></i><span> <?php echo e($myconsultant->offers->count()); ?> </span></a>
      
      </div>
      
      </td>
       <td>
      <div class="text-center">
     <?php if($myconsultant->contract->id): ?>  
        <a href="<?php echo e(route('contract.show' , $myconsultant->contract->id)); ?>" target="_blank"> <i class="fa fa-money"></i><span> العقود </span></a>
      <?php endif; ?>
      </div>
      
      </td>
            <td scope="col">
                  <div class="text-center">
                  <?php echo e($myconsultant->created_at->diffForHumans()); ?>

                  </div>

            
            </td>

     <td scope="col">
                  <div class="text-center">
                  <?php if($myconsultant->status == 0): ?>
                  ⏳ جاري تدقيق الملفات
                  <?php elseif($myconsultant->status == 1): ?>
                  💰 تم ارسال العرض
                  <?php elseif($myconsultant->status == 2): ?>
  ✍ تم قبول العرض - في انتظار توقيع الاتفاقية الالكترونية
                  <?php elseif($myconsultant->status == 3): ?>
جاري التنفيذ  👷 
             <?php else: ?> 
                          👍  تم التنفيذ 

<?php endif; ?>


                  </div>

            
            </td>
    </tr> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
  </tbody>
</table>



        </div>
     
        
       
        </div>
                <div class="col-lg-1"></div>

      </div>
    </div>
  </section>















<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ibrahim Elsanhouri\Desktop\komait\resources\views/consultants/myconsultants.blade.php ENDPATH**/ ?>