<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContractsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contracts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('offers_id')->unsigned();
            $table->foreign('offers_id')->references('id')->on('offers');
            $table->integer('cms_users_id')->unsigned();
            $table->foreign('cms_users_id')->references('id')->on('cms_users_id');
            $table->boolean('confirmed')->nullable()->default(false);
            $table->date('confirmed_at')->nullable();	

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contracts');
    }
}
