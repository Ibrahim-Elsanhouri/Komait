<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Contract; 
use App\Offer; 

class ContractController extends Controller
{
    //
    public function show($id){
        $contract = Contract::find($id); 
      //  dd($contract); 
        return view('contracts.show' , compact('contract'));

    }
    public function store(Request $request){
        Contract::create($request->all()); 
        $offer = Offer::find($request->offers_id);
      
        $consultant = $offer->consultant; 
        $consultant->status = 3; 
        $consultant->save();

        return redirect('/myconsultants')->with('info' ,  '💸تم توقيع الاتفاقية من طرفك الرجاء السداد لتفعيلها '); 
    }
}
