<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use App\Offer; 
class PaylinkController extends Controller
{
    //
    public function post_login($id){
      $offer = Offer::find($id);
  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://restapi.paylink.sa/api/auth",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS =>"{\r\n    \"apiId\":\"APP_ID_1596354703\",\r\n    \"secretKey\":\"0bc7b125-598a-3f3a-8b8a-cc6e79ed8167\",\r\n    \"persistToken\" : false\r\n  }",
    CURLOPT_HTTPHEADER => array(
      "Content-Type: application/json"
    ),
  ));
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
  $response = curl_exec($curl);
  
  curl_close($curl);
 // echo $response;

     $obj = json_decode($response);
     $id_token = $obj->id_token; 
    // dd($obj->id_token);
    return view('paylinks.payform' , compact('id_token' , 'offer')); 



}


public function create_invoice(){
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://restapi.paylink.sa/api/addInvoice",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS =>"{\r\n    \"amount\" : \"1\",\r\n    \"orderNumber\":\"Merchant-Order\",\r\n    \"callBackUrl\":\"https://www.example.com\",\r\n    \"clientName\":\"Ahmed Al-ahmed\",\r\n    \"clientMobile\":\"0509200900\",\r\n    \"note\":\"Please call us after payment to redeem code\",\r\n    \"clientEmail\":\"client@example.com\"\r\n  }",
  CURLOPT_HTTPHEADER => array(
    "Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhYmR1bGVsYWguc2FyYWhAZ21haWwuY29tIiwiYXV0aCI6IlJPTEVfTUVSQ0hBTlQsUk9MRV9NRVJDSEFOVF9BQ0NPVU5UIiwiZXhwIjoxNjA0MTgwMDM1fQ.6ihuTPjvZKgD-2krOVzHQ281-SHECJA954jwG3KQzE1kG7xlIEmKyVVcnfgd4t2lTCmTf9tqKkqnoPPVSyqQEw",
    "Content-Type: application/json"
  ),
));
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
$response = curl_exec($curl);

curl_close($curl);
echo $response;

}
}