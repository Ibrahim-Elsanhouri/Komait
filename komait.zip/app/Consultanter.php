<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Consultanter extends Model
{
    //
}
